Better Quickslots — v1.0.0 — Saturated

Optional version with a more pronounced rarity border.

FEATURES
The same thin diamond artwork with stronger border color and opacity.
Thin, stock-style item rarity borders for inventory, crafting, and gameplay
quickslots, plus inventory quickslot hover details. Preserves the original
artwork, icons, counts and layout. Borders update when displayed items change;
empty slots have no rarity outline. UE4SS is not required.

INSTALL / UPGRADE
Close the game. Extract this ZIP and copy all three files together into:
<game installation folder>\Dawnwalker\Content\Paks\~mods

00000000_BetterQuickslots_P.pak
00000000_BetterQuickslots_P.ucas
00000000_BetterQuickslots_P.utoc

Create ~mods if needed. Replace all three Better Quickslots files together.

Install either Default or Saturated, never both. To switch, replace all
three files together or disable the other variant in your mod manager.

UNINSTALL
Close the game and remove only the three Better Quickslots files listed above.
UE4SS and other mods can stay installed.

COMPATIBILITY
Other mods replacing WBP_Hub_NewInventory or WBP_HUD_Quickslots_Button may conflict.
Game updates may require rebuilding. The same button is used by inventory,
crafting and gameplay. Do not assume compatibility with every future game patch.
