Better Quickslots — v1.0.0

First stable release. The three installed mod files are byte-for-byte identical
to the confirmed v0.4.4 build. This release changes version labels and documentation,
with no gameplay or visual changes. Existing v0.4.4 users do not need to reinstall.

FEATURES
Thin, stock-style item rarity borders for inventory, crafting, and gameplay
quickslots, plus inventory quickslot hover details. Preserves the original
artwork, icons, counts and layout. Borders update when displayed items change;
empty slots have no rarity outline. UE4SS is not required.

INSTALL / UPGRADE
Close the game. Extract this ZIP and copy all three files together into:
<game installation folder>\Dawnwalker\Content\Paks\~mods

00000000_BetterQuickslots_P.pak
00000000_BetterQuickslots_P.ucas
00000000_BetterQuickslots_P.utoc

Create ~mods if needed. Replace all three Better Quickslots files together.
If upgrading from the former Quickslot Hover mod, remove its three old mod
files first or disable that version in your mod manager. These filenames will
not overwrite the old names. Never keep both versions installed.

UNINSTALL
Close the game and remove only the three Better Quickslots files listed above.
UE4SS and other mods can stay installed.

COMPATIBILITY
Other mods replacing WBP_Hub_NewInventory or WBP_HUD_Quickslots_Button may conflict.
Game updates may require rebuilding. The same button is used by inventory,
crafting and gameplay. Do not assume compatibility with every future game patch.

VALIDATION / SOURCE
Based on v0.4.4, confirmed working and visually approved in game. Package integrity,
recovered Blueprint assets, texture mip bytes and stock consumer compatibility
were verified for that build. v1.0.0 preserves the three mod files exactly.

Source, build instructions and release history:
https://github.com/t0ddharris/Better-Quickslots
