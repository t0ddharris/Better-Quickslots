Better Quickslots — v0.4.4

Extends the confirmed inventory rarity borders to crafting quickslots and the
main gameplay HUD through their shared quickslot button. Retains inventory hover
details, rarity colors, blue correction, and brightness.
Uses a single innermost outline made from the original stock diamond artwork.
The four outer layers are collapsed to remove the thick stepped bevel. Retains
the v0.4.3 private texture with its outer black halo trimmed at every mip level.
The original item background stays put; no shared game texture is replaced.
Borders update when the displayed item changes; empty slots have no rarity glow.
UE4SS is not required.

INSTALL / UPGRADE
Close the game. Copy the three .pak/.ucas/.utoc files together into:
<game installation folder>\Dawnwalker\Content\Paks\~mods
The files are now named 00000000_BetterQuickslots_P.pak/.ucas/.utoc.
When upgrading from the former Quickslot Hover mod, remove its three old mod
files first, or disable that version in your mod manager. The renamed files
will not overwrite the old filenames. For later upgrades, replace all three
Better Quickslots files together.

UNINSTALL
Close the game and remove these three 00000000_BetterQuickslots_P files.
To revert, remove these three files and install your previous release.

COMPATIBILITY / VALIDATION
Replaces WBP_Hub_NewInventory and WBP_HUD_Quickslots_Button, and includes the
two inventory-specific classes. Mods replacing either shared asset may conflict.
Other screens using the shared quickslot button also receive rarity borders.
v0.4.1 preserves the shared button's original property layout, correcting the
schema incompatibility introduced in v0.4.0. Added images are found through the
existing widget hierarchy without adding serialized class members.
v0.4.4 was confirmed working in game, including the thin stock-style border.
This is a branding and directory cleanup of that confirmed build. Package
integrity, all six asset round trips, and stock consumer compatibility pass.
Both external and inline texture mips are verified byte-for-byte after packing.
The local verification reference set lacks the stock Paper2D default material;
its two inherited import names cannot be recovered locally. Other imports match.

Check crafting and gameplay with different rarities, empty slots, reassigned and
consumed items, HUD hide/show, and inventory opening/closing. Inventory hover
details should continue to work.
